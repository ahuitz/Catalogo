<?php
/**
 * zx_slideshow.php
 *
 * @package ZX slideshow
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: zx_slideshow.php 2 2012-07-05 01:19:41Z numinix $
 */

define('BOX_CONFIGURATION_TM_MEGAMENU', 'TM Megamenu');