<?php

/**
 * Language definition for Related Products contribution
 * @author  Joe McFrederick
 * 
 * @package ZenCart
 * @subpackage language
 */
 
define('TEXT_PRODUCTS_FAMILY', 'Product Family Keyword:');