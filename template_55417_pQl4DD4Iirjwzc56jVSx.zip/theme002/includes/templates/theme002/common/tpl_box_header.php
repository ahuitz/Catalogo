<?php
/**
 * Common Template - tpl_box_header.php
 *
 * @package templateSystem
 * @copyright Copyright 2003-2005 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: tpl_box_header.php 2982 2006-02-07 07:56:41Z birdbrain $
 */
?>
<?php echo $content; ?>