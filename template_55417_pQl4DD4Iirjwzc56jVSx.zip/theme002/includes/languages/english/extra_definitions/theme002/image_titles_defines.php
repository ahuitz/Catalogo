<?php
/**
 *
 * @copyright Copyright 2010 Glenn Herbert
 * @license http://www.gnu.org/licenses/ GNU Public License V3.0
 * //includes/languages/english/extra_definitions/your_template/image_titles_defines.php
 * Ezpages Footer Columns  by Glenn Herbert (gjh42)    2010-09-01 - copied from master version in  Images for Titles  mod
 */
 
define('IMAGE_TITLES_EXT','.gif');// or .jpg, .png, etc.
?>