<?php
/*-------------------------------
*
*	Define box heading for 
*	/templates/tpl_modules/related_products.php
*
*--------------------------------*/
define('BOX_HEADING_RELATED_PRODUCTS','Related Products');

/* End of File */